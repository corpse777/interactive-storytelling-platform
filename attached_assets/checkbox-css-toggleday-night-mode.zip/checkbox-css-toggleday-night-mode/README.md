# Checkbox CSS Toggle - Day / Night Mode

A Pen created on CodePen.

Original URL: [https://codepen.io/bubbleteameimei/pen/Byaoepa](https://codepen.io/bubbleteameimei/pen/Byaoepa).

Checkbox CSS Toggle - Day / Night Mode