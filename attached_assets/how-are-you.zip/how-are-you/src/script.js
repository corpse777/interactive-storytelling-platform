/*
Respect is due:

Star rating made with a little love and guidance from James Barnett's Pure CSS Star Rating Widget codepen.
- https://codepen.io/jamesbarnett/pen/vlpkh

5 star happiness inspired by Cécile L. Parker's Good morning! dribbble shot.
- https://dribbble.com/shots/2486351-Good-morning
*/