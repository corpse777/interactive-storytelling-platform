# How Are You?

A Pen created on CodePen.

Original URL: [https://codepen.io/hexagoncircle/pen/bEMWyj](https://codepen.io/hexagoncircle/pen/bEMWyj).

A CSS rating system that changes the facial expression based on how many stars are chosen.