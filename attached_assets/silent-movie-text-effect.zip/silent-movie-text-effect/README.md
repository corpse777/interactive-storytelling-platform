# Silent Movie Text Effect

A Pen created on CodePen.

Original URL: [https://codepen.io/bubbleteameimei/pen/EaxoGvr](https://codepen.io/bubbleteameimei/pen/EaxoGvr).

I used forks of

Ibe's Pen Background Noise - Canvas
https://codepen.io/IbeVanmeenen/full/vZzgvg/

and

Diaco M.Lotfollahi's Pen GSAP Old Movie Style.
https://codepen.io/MAW/full/rxqqQG/

I tried to reproduce a screen from "The Poor Little Rich Girl" movie